OUR LITTLE UNIVERSE — JAKE & ELEA

This is a free, mobile-friendly monthsary webpage.

PREVIEW
Open index.html in a browser to preview it.

ADD YOUR PHOTOS
1. Put three photo files in the same folder as index.html.
2. Name them photo1.jpg, photo2.jpg, and photo3.jpg.
3. In index.html, find the three photo placeholder blocks and replace each block with:
   <div class="photo"><img src="photo1.jpg" alt="A favorite memory"></div>
   Use photo2.jpg and photo3.jpg for the other two blocks.
4. Save the file and preview again.

PERSONALIZE
Open index.html in a text editor and change the monthsary date, letter, and surprise message to your own words.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Sign in or create a GitHub account.
2. Create a new public repository named: our-little-universe
3. Upload index.html and your three photo files to the repository's main branch (README.txt is optional).
4. Open the repository's Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and / (root), then Save.
7. Wait for GitHub to publish. Your public link will look like:
   https://YOUR-USERNAME.github.io/our-little-universe/

You can send that link to Elea. Anyone with the link can view the page, so only upload photos you're comfortable sharing.
